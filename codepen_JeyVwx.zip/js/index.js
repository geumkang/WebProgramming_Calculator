JS
function doDisplay(){
    var con = document.getElementById("result");
    if(con.style.display=='none'){
        con.style.display = 'block';
    }else{
        con.style.display = 'none';
    }
}


function doDisplaybutton(){
    var con = document.getElementById("operator");
    if(con.style.display=='none'){
        con.style.display = 'block';
    }else{
        con.style.display = 'none';
    }
}